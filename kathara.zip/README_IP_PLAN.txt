Group1_6 Kathara topology with RIP routing

Run:
  kathara lstart
Test examples:
  kathara connect b1_students
  ping 192.168.54.10

Routers:
  r0_core connects all six block routers by /30 WAN links.
  r1_block1 ... r6_block6 provide gateways for LAN subnets.

IP addressing plan:

Network Block 1:
  180 PCs                  192.168.1.0/24     gateway 192.168.1.1/24, test host 192.168.1.10/24, broadcast 192.168.1.255
  90 Laptops               192.168.2.0/25     gateway 192.168.2.1/25, test host 192.168.2.10/25, broadcast 192.168.2.127
  40 Laptops               192.168.3.0/26     gateway 192.168.3.1/26, test host 192.168.3.10/26, broadcast 192.168.3.63
  12 PCs                   192.168.4.0/28     gateway 192.168.4.1/28, test host 192.168.4.10/28, broadcast 192.168.4.15
  80 servers               192.168.5.0/25     gateway 192.168.5.1/25, test host 192.168.5.10/25, broadcast 192.168.5.127

Network Block 2:
  97 PCs                   192.168.10.0/25    gateway 192.168.10.1/25, test host 192.168.10.10/25, broadcast 192.168.10.127
  77 Laptops               192.168.11.0/25    gateway 192.168.11.1/25, test host 192.168.11.10/25, broadcast 192.168.11.127
  32 Laptops               192.168.12.0/26    gateway 192.168.12.1/26, test host 192.168.12.10/26, broadcast 192.168.12.63
  15 PCs                   192.168.13.0/27    gateway 192.168.13.1/27, test host 192.168.13.10/27, broadcast 192.168.13.31
  32 servers               192.168.14.0/26    gateway 192.168.14.1/26, test host 192.168.14.10/26, broadcast 192.168.14.63

Network Block 3:
  74 Workstations          192.168.20.0/25    gateway 192.168.20.1/25, test host 192.168.20.10/25, broadcast 192.168.20.127
  49 Research Laptops      192.168.21.0/26    gateway 192.168.21.1/26, test host 192.168.21.10/26, broadcast 192.168.21.63
  34 Test Laptops          192.168.22.0/26    gateway 192.168.22.1/26, test host 192.168.22.10/26, broadcast 192.168.22.63
  29 PCs                   192.168.23.0/27    gateway 192.168.23.1/27, test host 192.168.23.10/27, broadcast 192.168.23.31
  44 servers               192.168.24.0/26    gateway 192.168.24.1/26, test host 192.168.24.10/26, broadcast 192.168.24.63

Network Block 4:
  171 servers              192.168.30.0/24    gateway 192.168.30.1/24, test host 192.168.30.10/24, broadcast 192.168.30.255
  61 Admin PCs             192.168.31.0/26    gateway 192.168.31.1/26, test host 192.168.31.10/26, broadcast 192.168.31.63
  41 Operator Laptops      192.168.32.0/26    gateway 192.168.32.1/26, test host 192.168.32.10/26, broadcast 192.168.32.63
  36 Support Laptops       192.168.33.0/26    gateway 192.168.33.1/26, test host 192.168.33.10/26, broadcast 192.168.33.63
  31 Monitoring PCs        192.168.34.0/26    gateway 192.168.34.1/26, test host 192.168.34.10/26, broadcast 192.168.34.63

Network Block 5:
  125 IoT Nodes            192.168.40.0/25    gateway 192.168.40.1/25, test host 192.168.40.10/25, broadcast 192.168.40.127
  35 Tablets               192.168.41.0/26    gateway 192.168.41.1/26, test host 192.168.41.10/26, broadcast 192.168.41.63
  25 Maintenance Laptops   192.168.42.0/27    gateway 192.168.42.1/27, test host 192.168.42.10/27, broadcast 192.168.42.31
  15 Control PCs           192.168.43.0/27    gateway 192.168.43.1/27, test host 192.168.43.10/27, broadcast 192.168.43.31
  25 servers               192.168.44.0/27    gateway 192.168.44.1/27, test host 192.168.44.10/27, broadcast 192.168.44.31

Network Block 6:
  57 Analyst PCs           192.168.50.0/26    gateway 192.168.50.1/26, test host 192.168.50.10/26, broadcast 192.168.50.63
  37 SOC Laptops           192.168.51.0/26    gateway 192.168.51.1/26, test host 192.168.51.10/26, broadcast 192.168.51.63
  22 Forensic Laptops      192.168.52.0/27    gateway 192.168.52.1/27, test host 192.168.52.10/27, broadcast 192.168.52.31
  20 Isolated PCs          192.168.53.0/27    gateway 192.168.53.1/27, test host 192.168.53.10/27, broadcast 192.168.53.31
  52 servers               192.168.54.0/26    gateway 192.168.54.1/26, test host 192.168.54.10/26, broadcast 192.168.54.63

WAN links:
  r0_core - r1_block1: 192.168.100.0/30   r0=192.168.100.1/30, r1=192.168.100.2/30
  r0_core - r2_block2: 192.168.100.4/30   r0=192.168.100.5/30, r2=192.168.100.6/30
  r0_core - r3_block3: 192.168.100.8/30   r0=192.168.100.9/30, r3=192.168.100.10/30
  r0_core - r4_block4: 192.168.100.12/30   r0=192.168.100.13/30, r4=192.168.100.14/30
  r0_core - r5_block5: 192.168.100.16/30   r0=192.168.100.17/30, r5=192.168.100.18/30
  r0_core - r6_block6: 192.168.100.20/30   r0=192.168.100.21/30, r6=192.168.100.22/30
